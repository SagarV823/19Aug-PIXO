package com.pixo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.pixo.bean.MyMedia;
import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UserComments;
import com.pixo.bean.AccountDetails;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	public UserService userService;
	
	@Autowired
	public UserDAO userDAO;
	
	static Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="registerUser",method=RequestMethod.GET)
	public ModelAndView registerUser(@ModelAttribute AccountDetails user){
		ModelAndView mv=new ModelAndView();
		boolean result=userService.registerUser(user);
		if(result)
			logger.info("Registration successful !");
		else
			logger.warn("Registration failed ! Check EmailId or Password ...");
		mv.addObject("Registerstatus","Successfully registered! Proceed to login Page!");
		mv.setViewName("Login");
		return mv;
	}
	
	@RequestMapping(value="loginUser",method=RequestMethod.POST)
    public ModelAndView UserAuthentication(@RequestParam("EmailId") String emailId,@RequestParam("Password") String password,HttpServletRequest request){	
		
		logger.info("Credential A Authenticating ...");	      	      
	  	ModelAndView mv=new ModelAndView();
    	boolean result=userService.authenticate(emailId, password);
    	HttpSession session=request.getSession();
    	session.setAttribute("EmailId", emailId);
    	
    	if(result){
    		logger.info("Authentication Successful ...");
    		AccountDetails user=userService.getUser(emailId);
    		String name=user.getName();
    		int id=user.getId();
    		session.setAttribute("UserId", id);
    		mv.addObject("userid",id);
    		mv.setViewName("Welcome");
    		mv.addObject("username",name);
    	}
    	else{	
    		logger.warn("Authentication failed ! Wrong Email or Password ...");	
    		mv.addObject("status","Wrong Email or Password!");
			mv.setViewName("Login");
    	}   	
    	return mv;
    }
	
	@RequestMapping(value="home")
    public ModelAndView Home(HttpServletRequest request){	
		
		logger.info("Credential A Authenticating ...");	      	      
	  	ModelAndView mv=new ModelAndView();
    	HttpSession session=request.getSession();
    	String emailId=(String)request.getSession().getAttribute("EmailId");
    	session.setAttribute("EmailId", emailId);    	    
    		AccountDetails user=userService.getUser(emailId);
    		String name=user.getName();
    		int id=user.getId();
    		session.setAttribute("UserId", id);
    		mv.addObject("userid",id);
    		mv.setViewName("Welcome");
    		mv.addObject("username",name);  	    	
    		logger.warn("Home Page");	   	
    	return mv;
    }
	
	 @RequestMapping(value = "uploadPicture", method = RequestMethod.POST)
	    public ModelAndView handleFileUpload(HttpServletRequest request,@RequestParam CommonsMultipartFile[] profilePicture) throws Exception {
	          ModelAndView mv=new ModelAndView();
	        if (profilePicture != null && profilePicture.length > 0) {
	            for (CommonsMultipartFile aFile : profilePicture)
	            {      
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                ProfilePicture pic = new ProfilePicture();
	                pic.setFileName(aFile.getOriginalFilename());
	                pic.setData(aFile.getBytes());
	                pic.setUserId(userId);
	                boolean result=userDAO.uploadProfilePicture(pic);
	                if(result)
	                {
	                	mv.addObject("status","Uploaded succesfully!");
	                	mv.setViewName("Welcome");
	                }
	            }
	        }	  
	        return mv;
	    }
	 @RequestMapping(value = "showImage")
	 public ModelAndView showImage(HttpServletRequest request, HttpServletResponse response){	
			ModelAndView mv=new ModelAndView();	
	    	HttpSession session=request.getSession();
	    	int userId=(int)request.getSession().getAttribute("UserId"); 
	    	ProfilePicture picture=userDAO.showImage(userId);
	    	int picId=picture.getId();
	    	System.out.println("Pic id is "+ picId);
	    	response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	        try {
				response.getOutputStream().write(picture.getData());
				response.getOutputStream().close();
			} catch (IOException e) {			
				e.printStackTrace();
			}
	        mv.addObject("picture",picture);
	    	return mv;
	    }
	 
	 @RequestMapping(value = "uploadMedia", method = RequestMethod.POST)
	    public ModelAndView uploadMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
	    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
	          ModelAndView mv=new ModelAndView();
	        if (media != null && media.length > 0) {
	            for (CommonsMultipartFile aFile : media)
	            {      
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                MyMedia myMedia=new MyMedia();
	                myMedia.setMedia(aFile.getBytes());
	                myMedia.setTitle(title);
	                myMedia.setDescription(description);
	                myMedia.setTag(tags);
	                myMedia.setUserId(userId);
	                boolean result=userDAO.uploadMedia(myMedia);
	                if(result)
	                {
	                	mv.addObject("status","Uploaded succesfully!");
	                	mv.setViewName("UploadSingle");
	                }
	            }
	        }	  
	        return mv;
	    }
	 @RequestMapping(value = "uploadMultipleMedia", method = RequestMethod.POST)
	    public ModelAndView uploadMultipleMedia(HttpServletRequest request,@RequestParam CommonsMultipartFile[] media,@RequestParam("title") String title,
	    		@RequestParam("description") String description,@RequestParam("tags") String tags) throws Exception {
	          ModelAndView mv=new ModelAndView();
	        if (media != null && media.length > 0) {
	            for (CommonsMultipartFile aFile : media)
	            {      
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                MyMedia myMedia=new MyMedia();
	                myMedia.setMedia(aFile.getBytes());
	                myMedia.setTitle(title);
	                myMedia.setDescription(description);
	                myMedia.setTag(tags);
	                myMedia.setUserId(userId);
	                boolean result=userDAO.uploadMedia(myMedia);
	                if(result)
	                {
	                	mv.addObject("status","Uploaded succesfully!");
	                	mv.setViewName("UploadMultiple");
	                }
	            }
	        }	  
	        return mv;
	    }
	 @RequestMapping(value="welcome")
	    public ModelAndView WelcomePage(HttpServletRequest request){	
			
			logger.info("Credential A Authenticating ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("emailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	mv.addObject("userid",id);
	    	mv.setViewName("Welcome");
	    	mv.addObject("username",name);   	
	    	return mv;
	    }
	 
	 @RequestMapping(value="likesComments")
	 public ModelAndView likesCommentsPage(HttpServletRequest request){				
			logger.info("Redirecting to comments page ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	ProfilePicture picture=userDAO.showImage(id);
	    	String title=picture.getFileName();
	    	session.setAttribute("UserId", id);
	    	mv.addObject("userid",id);
	    	mv.addObject("title",title);
	    	mv.setViewName("LikesComments");
	    	mv.addObject("username",name);   
	    	
	    	
	    	int picId=picture.getId();
	    	System.out.println("Pic "+picId);
	    	List<UserComments> allcomments=userService.showComments(picId);
	    	mv.addObject("AllComments",allcomments);
	    	mv.setViewName("LikesComments");
	    	return mv;
	    }
	 	 	
	 @RequestMapping(value="addComment", method = RequestMethod.POST)
	 	public ModelAndView addComment(HttpServletRequest request, HttpServletResponse response,@RequestParam("comment") String comment) {
		 ModelAndView mv=new ModelAndView();
		 UserComments cmt=new UserComments();
		 
		 HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int userid=user.getId();
	    	ProfilePicture picture=userDAO.showImage(userid);
	    	String title=picture.getFileName();
	    	int picid=picture.getId();
	    	session.setAttribute("UserId", userid);
	    	cmt.setUserId(userid);
	    	cmt.setPicId(picid);			 
	    	cmt.setComment(comment);
	    	userService.addComment(cmt);
	    	mv.setViewName("LikesComments");
	    	mv.addObject("title",title);
	    	mv.addObject("status","comment added!");
		 return mv;
	 }
	 
	 @RequestMapping(value="updateUser",method=RequestMethod.POST)
	 public ModelAndView UpdateUser(HttpServletRequest request,@RequestParam("username") String userName,@RequestParam("password") String password,
			 @RequestParam("email") String email){	
			
			logger.info("Updating user details ...");	      	      
		  	ModelAndView mv=new ModelAndView();
	    	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	AccountDetails user=userService.getUser(emailId);
	    	String name=user.getName();
	    	int id=user.getId();
	    	session.setAttribute("UserId", id);
	    	boolean result=false;
	    	result=userService.updateUser(id, userName, password, email);
	    	System.out.println("result = "+result);
	    	mv.addObject("userid",id);
	    	if(result)
	    		mv.addObject("status","updated successfully!");
	    	mv.addObject("username",name);   	
	    	mv.setViewName("AccountUpdate");
	    	return mv;
	    }
	 
	 @RequestMapping("myMedia")
	 	public ModelAndView MyMedia(HttpServletRequest request, HttpServletResponse response){
		 System.out.println("In myMedia Func");
		 ModelAndView mv=new ModelAndView();
		 List<MyMedia> allMedia=new ArrayList<MyMedia>();
		  	HttpSession session=request.getSession();
	    	String emailId=(String)request.getSession().getAttribute("EmailId"); 
	    	System.out.println("In myMedia Func email "+emailId);
	    	AccountDetails user=userService.getUser(emailId);
	    	
	    	int id=user.getId();
	    	System.out.println("ID is "+ id);
	    	String name=user.getName();
	    	mv.addObject("userid",id);
	    	mv.addObject("username",name);
	    	
	    	System.out.println("Here ");
	    	
	    	//allMedia=userDAO.showMedia(id);	    	
	    	/*for(com.pixo.bean.MyMedia l:allMedia){	    		
	    		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
		       try {
				response.getOutputStream().write(l.getMedia());
					//response.getOutputStream().close();				
		        	mv.addObject("response",response);
				} catch (IOException e) {			
					e.printStackTrace();
				}	    
	    	}	 */
	    	mv.addObject("allMedia",allMedia);
	    	System.out.println("After adding the whole table to list!");
	    	mv.setViewName("AllMedia");
	    	return mv;		 
	 }
	 
	 
}
