package com.pixo.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class UserComments {

	private int userId;
	private int picId;
	private String comments;
	private int noOfLikes;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	public UserComments() {}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPicId() {
		return picId;
	}
	public void setPicId(int picId) {
		this.picId = picId;
	}
	public String getComment() {
		return comments;
	}
	public void setComment(String comments) {
		this.comments = comments;
	}
	public int getNoOfLikes() {
		return noOfLikes;
	}
	public void setNoOfLikes(int noOfLikes) {
		this.noOfLikes = noOfLikes;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "UserComments [userId=" + userId + ", picId=" + picId + ", comments=" + comments + ", noOfLikes="
				+ noOfLikes + ", id=" + id + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comments == null) ? 0 : comments.hashCode());
		result = prime * result + id;
		result = prime * result + noOfLikes;
		result = prime * result + picId;
		result = prime * result + userId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserComments other = (UserComments) obj;
		if (comments == null) {
			if (other.comments != null)
				return false;
		} else if (!comments.equals(other.comments))
			return false;
		if (id != other.id)
			return false;
		if (noOfLikes != other.noOfLikes)
			return false;
		if (picId != other.picId)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	
	
}
